==============================
  WALLHACKS VFX PACK FOR UEFN
==============================

This is a custom visual effect pack made for Unreal Editor for Fortnite (UEFN).

IMPORTANT:
- This is NOT a hack or cheat.
- The effect is purely VISUAL and intended for Creative gameplay.

------------------------------
  WHAT'S INCLUDED
------------------------------

> Textures/
    ├── .png/           <-- Raw texture files (preview or editing use)
    └── .uasset/        <-- UEFN-ready texture assets

> Niagara/             	 <-- Niagara VFX system for player highlight

> Material/              <-- Custom materials used in the effect

> README.txt             <-- This file

------------------------------
  FREE VERSION DETAILS
------------------------------

This is the FREE version of the Wallhacks VFX Pack.

To get the FULL version with:
- Extra materials
- More Colors
- Optimized performance

BUY IT HERE:
>>> https://buymeacoffee.com/itsmarwan/e/396983 <<<

Verse scripting credits:
@ShootDangCreations (YouTube)

- Thank you for using the Wallhacks VFX Pack!
